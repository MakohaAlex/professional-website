// script.js

// Scroll-to-Top Button
const scrollTopBtn = document.createElement('button');
scrollTopBtn.innerText = "↑";
scrollTopBtn.classList.add('fixed', 'bottom-5', 'right-5', 'bg-blue-500', 'text-white', 'p-3', 'rounded-full', 'hidden');
document.body.appendChild(scrollTopBtn);

window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        scrollTopBtn.classList.remove('hidden');
    } else {
        scrollTopBtn.classList.add('hidden');
    }
});

scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Form Validation
const form = document.querySelector('form');
form.addEventListener('submit', (e) => {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    if (!name || !email || !message) {
        alert('Please fill in all fields.');
        e.preventDefault();
    } else if (!validateEmail(email)) {
        alert('Please enter a valid email address.');
        e.preventDefault();
    }
});

function validateEmail(email) {
    const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return re.test(String(email).toLowerCase());
}
